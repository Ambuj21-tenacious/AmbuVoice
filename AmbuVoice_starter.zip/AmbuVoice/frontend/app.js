// AmbuVoice client
// - Captures mic, encodes 16kHz PCM16, sends base64 frames to our server via WS
// - Plays back 24kHz PCM16 frames coming from Gemini
let ws;
let mediaStream;
let audioCtx;
let processor;
let playingQueue = [];
let playing = false;

const connectBtn = document.getElementById("connectBtn");
const disconnectBtn = document.getElementById("disconnectBtn");
const micLevelEl = document.getElementById("micLevel");
const statusEl = document.getElementById("status");
const logEl = document.getElementById("log");
const textInput = document.getElementById("textInput");

function log(msg){
  const div = document.createElement("div");
  div.textContent = msg;
  logEl.appendChild(div);
  logEl.scrollTop = logEl.scrollHeight;
}

async function connect(){
  if (ws) return;
  statusEl.textContent = "connecting…";
  ws = new WebSocket(`ws://localhost:5173/live`);
  ws.binaryType = "arraybuffer";

  ws.onopen = () => {
    statusEl.textContent = "connected";
    connectBtn.disabled = true;
    disconnectBtn.disabled = false;
    startMic();
  };
  ws.onmessage = (event) => {
    try {
      // Messages could be JSON (server/model events) or binary/base64 audio
      if (typeof event.data === "string") {
        // Attempt to parse JSON; if it fails, treat as base64 audio
        try {
          const msg = JSON.parse(event.data);
          if (msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
            // Some SDKs wrap audio chunks like this, but our server forwards raw {data}
            enqueueBase64Pcm16(msg.serverContent.modelTurn.parts[0].inlineData.data, 24000);
          } else if (msg.data) {
            enqueueBase64Pcm16(msg.data, 24000);
          } else if (msg.inputTranscription?.text) {
            log("You: " + msg.inputTranscription.text);
          } else if (msg.serverContent?.modelTurn?.parts?.[0]?.text) {
            log("AmbuVoice: " + msg.serverContent.modelTurn.parts[0].text);
          } else if (msg.error) {
            log("Error: " + msg.error);
          }
        } catch {
          // Treat as base64 audio
          enqueueBase64Pcm16(event.data, 24000);
        }
      } else {
        // Binary not expected in our simple relay; ignore
      }
    } catch (e) {
      console.error(e);
    }
  };
  ws.onclose = () => {
    statusEl.textContent = "disconnected";
    connectBtn.disabled = false;
    disconnectBtn.disabled = true;
    stopMic();
    ws = null;
  };
  ws.onerror = (e) => log("WS error");
}

function disconnect(){
  if(ws) ws.close();
}

async function startMic(){
  audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
  mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const source = audioCtx.createMediaStreamSource(mediaStream);

  processor = audioCtx.createScriptProcessor(4096, 1, 1);
  source.connect(processor);
  processor.connect(audioCtx.destination);

  processor.onaudioprocess = (event) => {
    const input = event.inputBuffer.getChannelData(0);
    // Compute simple RMS for mic level
    let sum = 0;
    for (let i=0;i<input.length;i++){ sum += input[i]*input[i]; }
    const rms = Math.sqrt(sum/input.length);
    micLevelEl.textContent = (rms*100).toFixed(0);

    // Convert float [-1,1] to 16-bit PCM and base64 encode
    const pcm16 = floatTo16BitPCM(input);
    const b64 = arrayBufferToBase64(pcm16.buffer);
    sendAudioChunk(b64);
  };
}

function stopMic(){
  try{ processor?.disconnect(); }catch{}
  try{ mediaStream?.getTracks().forEach(t=>t.stop()); }catch{}
  try{ audioCtx?.close(); }catch{}
  processor = null; mediaStream = null; audioCtx = null;
}

function sendAudioChunk(base64){
  if (!ws || ws.readyState !== 1) return;
  ws.send(JSON.stringify({
    type: "audio",
    data: base64,
    mimeType: "audio/pcm;rate=16000"
  }));
}

function floatTo16BitPCM(float32Array){
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  let offset = 0;
  for (let i=0; i<float32Array.length; i++, offset += 2){
    let s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }
  return new Int16Array(buffer);
}
function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.slice(i, i + chunk));
  }
  return btoa(binary);
}

// Playback: enqueue and play 24kHz PCM16 chunks
function enqueueBase64Pcm16(b64, sampleRate){
  const raw = atob(b64);
  const buf = new ArrayBuffer(raw.length);
  const bytes = new Uint8Array(buf);
  for (let i=0;i<raw.length;i++) bytes[i] = raw.charCodeAt(i);
  playPcm16(new Int16Array(buf), sampleRate);
}

async function playPcm16(int16, sampleRate){
  playingQueue.push({ int16, sampleRate });
  if (playing) return;
  playing = true;
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });

  while (playingQueue.length){
    const { int16, sampleRate } = playingQueue.shift();
    const audioBuffer = audioCtx.createBuffer(1, int16.length, sampleRate);
    // Convert Int16 to Float32
    const f32 = new Float32Array(int16.length);
    for (let i=0;i<int16.length;i++) f32[i] = int16[i] / 0x8000;
    audioBuffer.copyToChannel(f32, 0);
    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioCtx.destination);
    source.start();
    await new Promise(res => source.onended = res);
  }
  playing = false;
}

// Text input support
textInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && textInput.value.trim()){
    const text = textInput.value.trim();
    ws?.send(JSON.stringify({ type: "text", text }));
    log("You: " + text);
    textInput.value = "";
  }
});

connectBtn.addEventListener("click", connect);
disconnectBtn.addEventListener("click", disconnect);
