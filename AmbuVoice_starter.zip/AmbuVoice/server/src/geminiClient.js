
/**
 * Minimal Gemini Live WebSocket client.
 * - Opens a WS to Gemini Live (wss://generativelanguage.googleapis.com/ws/...)
 * - Sends initial setup with model + response modalities (AUDIO)
 * - Forwards realtime audio frames (16kHz PCM16) from our server to Gemini Live
 * - Emits back audio chunks received from Gemini (24kHz PCM16 base64) to our server
 */
import WebSocket from "ws";

const GEMINI_WS_URL =
  "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";

/**
 * Create a Gemini Live session.
 * @param {Object} opts
 * @param {string} opts.apiKey - Google Gemini API Key
 * @param {string} [opts.model="models/gemini-2.5-flash-preview-native-audio-dialog"]
 * @param {(data: object) => void} onMessage - callback for messages from Gemini
 * @returns {WebSocket} ws
 */
export function createGeminiSession(
  { apiKey, model = "models/gemini-2.5-flash-preview-native-audio-dialog" },
  onMessage
) {
  const url = `${GEMINI_WS_URL}?key=${encodeURIComponent(apiKey)}`;
  const ws = new WebSocket(url);

  ws.on("open", () => {
    // Send setup message first
    const setup = {
      setup: {
        model,
        generationConfig: {
          responseModalities: ["AUDIO"], // we want audio back
          // Optional: control temperature, etc.
          temperature: 0.7
        },
        systemInstruction: {
          role: "system",
          parts: [{ text: "You are AmbuVoice, a friendly, helpful voice assistant." }]
        },
        // Enable input/output transcriptions if needed:
        inputAudioTranscription: {},
        outputAudioTranscription: {}
      }
    };
    ws.send(JSON.stringify(setup));
  });

  ws.on("message", (data) => {
    try {
      const msg = JSON.parse(data.toString());
      onMessage?.(msg);
    } catch (e) {
      // Non-JSON messages from Gemini are usually audio data (base64)
      onMessage?.({ data: data.toString() });
    }
  });

  ws.on("error", (err) => {
    console.error("Gemini WS error:", err);
  });

  return ws;
}
