
import 'dotenv/config';
import express from "express";
import cors from "cors";
import morgan from "morgan";
import { WebSocketServer } from "ws";
import { createGeminiSession } from "./geminiClient.js";

const app = express();
app.use(cors());
app.use(morgan("dev"));

// Health endpoint
app.get("/health", (_, res) => res.json({ ok: true, name: "AmbuVoice" }));

const port = process.env.PORT || 5173;
const server = app.listen(port, () => {
  console.log(`AmbuVoice server listening on http://localhost:${port}`);
});

// Upgrade to WebSocket for audio streaming at /live
const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (req, socket, head) => {
  if (req.url?.startsWith("/live")) {
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", (clientWs) => {
  console.log("Browser connected to /live");

  // Open Gemini Live session
  const apiKey = process.env.GOOGLE_API_KEY;
  if (!apiKey) {
    clientWs.send(JSON.stringify({ error: "Server missing GOOGLE_API_KEY" }));
    clientWs.close();
    return;
  }

  const geminiWs = createGeminiSession(
    { apiKey },
    (message) => {
      // Forward Gemini server messages (including audio chunks) back to browser
      try {
        // Some messages are JSON, others may be binary/base64 audio
        if (typeof message === "string") {
          clientWs.send(message);
        } else {
          clientWs.send(JSON.stringify(message));
        }
      } catch (e) {
        console.error("Error sending to browser:", e);
      }
    }
  );

  clientWs.on("message", (data) => {
    // The browser will send JSON messages and base64 audio chunks
    // Expect either:
    //  - { type: "audio", data: "<base64>", mimeType: "audio/pcm;rate=16000" }
    //  - { type: "text", text: "Hello AmbuVoice!" }
    try {
      const msg = JSON.parse(data.toString());
      if (msg.type === "audio") {
        const payload = {
          realtimeInput: {
            audio: {
              data: msg.data,
              mimeType: msg.mimeType || "audio/pcm;rate=16000"
            }
          }
        };
        geminiWs.send(JSON.stringify(payload));
      } else if (msg.type === "text") {
        const payload = {
          clientContent: {
            turns: [
              {
                role: "user",
                parts: [{ text: msg.text }]
              }
            ],
            turnComplete: true
          }
        };
        geminiWs.send(JSON.stringify(payload));
      }
    } catch (e) {
      console.error("Bad client message:", e);
    }
  });

  // Close handling
  const cleanup = () => {
    try { geminiWs?.close(); } catch {}
    try { clientWs?.close(); } catch {}
  };
  clientWs.on("close", cleanup);
});

