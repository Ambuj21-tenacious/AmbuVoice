# Minimal Python Live API sample (offline demo)
# pip install google-genai librosa soundfile
# Put a 16 kHz mono PCM WAV file as sample.wav in this folder.
import asyncio, io, wave
from google import genai
from google.genai import types
import librosa, soundfile as sf

MODEL = "gemini-2.5-flash-preview-native-audio-dialog"

async def main():
    client = genai.Client()  # uses GOOGLE_API_KEY from env
    async with client.aio.live.connect(model=MODEL, config={
        "response_modalities": ["AUDIO"],
        "system_instruction": "You are AmbuVoice, a friendly helper."
    }) as session:
        buf = io.BytesIO()
        y, sr = librosa.load("sample.wav", sr=16000)
        sf.write(buf, y, sr, format="RAW", subtype="PCM_16")
        buf.seek(0)
        await session.send_realtime_input(audio=types.Blob(data=buf.read(), mime_type="audio/pcm;rate=16000"))
        wf = wave.open("reply.wav", "wb")
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(24000)
        async for resp in session.receive():
            if resp.data is not None:
                wf.writeframes(resp.data)
        wf.close()

if __name__ == "__main__":
    asyncio.run(main())
